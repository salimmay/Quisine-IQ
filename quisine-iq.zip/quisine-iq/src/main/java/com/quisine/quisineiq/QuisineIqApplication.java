package com.quisine.quisineiq;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuisineIqApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuisineIqApplication.class, args);
	}

}
